#ifndef BASE
#define BASE
#include <cstdio>
#include <string>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#endif