test_name="test_hash_game.cpp"
g++ $test_name -o test.o -Wall

./test.o