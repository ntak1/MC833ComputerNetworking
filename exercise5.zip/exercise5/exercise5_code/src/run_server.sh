#!/bin/bash
make

# Launch the clients
../bin/server.o 5012